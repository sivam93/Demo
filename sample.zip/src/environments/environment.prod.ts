export const BASE_URL: string = "https://css-api.teamlease.com/v1";

export const environment = {
  apiUrl: "api/",

  URL: BASE_URL,

  production: true
};
