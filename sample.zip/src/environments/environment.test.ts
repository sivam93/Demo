export const BASE_URL: string =
  "http://css-service-test.ap-south-1.elasticbeanstalk.com/v1";

export const environment = {
  apiUrl: "api/",

  URL: BASE_URL,

  production: false
};
