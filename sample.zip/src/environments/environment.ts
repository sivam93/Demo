export const BASE_URL: string ="https://localhost:44344/v1";
 // "http://css-service-test.ap-south-1.elasticbeanstalk.com/v1";

export const environment = {
  apiUrl: "api/",

  URL: BASE_URL,
  production: false
};
