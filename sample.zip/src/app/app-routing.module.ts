import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";

import { LoginComponent } from "./components/login/login.component";
import { AutocompleteComponent } from "./autocomplete/autocomplete.component";
const routes: Routes = [
 
  { path: "", component: LoginComponent },
  { path: "auto", component: AutocompleteComponent }];

export const appRoutingModule = RouterModule.forRoot(routes);
@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
      //onSameUrlNavigation: 'ignore',
      onSameUrlNavigation: "reload"
    })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}
