export * from "./login.component";
