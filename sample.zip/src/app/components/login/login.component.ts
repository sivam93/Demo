import { Component, OnInit } from "@angular/core";
import { Router, ActivatedRoute } from "@angular/router";
import { NgForm } from "@angular/forms";


interface loginValues {
  Username: string;
  Password: string;
}
@Component({
  selector: "app-login",
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.scss"]
})
export class LoginComponent implements OnInit {
  constructor(private router:Router){

  }
  ngOnInit() {
  }
  formValues: loginValues = {
    Username: null,
    Password: null,
  }
 
  login(form: NgForm) {

    this.formValues = {
      Username: this.formValues.Username,
      Password: this.formValues.Password
    }
    if(this.formValues){
      this.router.navigateByUrl("/auto")
    }
  }

   
}
