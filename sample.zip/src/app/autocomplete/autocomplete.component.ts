import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { FormControl } from '@angular/forms';
import {map, startWith, debounceTime, distinctUntilChanged, switchMap, tap} from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-autocomplete',
  templateUrl: './autocomplete.component.html',
  styleUrls: ['./autocomplete.component.scss']
})
export class AutocompleteComponent implements OnInit {
  filteredOptions: Observable<string[]>;
  myControl = new FormControl();
  opts:any = [];
  constructor(private service: HttpClient) { 
  //  this.getData();
    setTimeout(() => {
      this.filteredOptions = this.myControl.valueChanges
      .pipe(
        startWith(''),
        map(value => this._filter(value))
      );
    }, 2000);
       }

       private _filter(value: string): string[] {
        const filterValue = value.toLowerCase();
    
        return this.opts.filter(option => option.toLowerCase().includes(filterValue));
      }
      click($event){
        if($event.target.value){
        let url="http://localhost:8080/rest/employeees/"+$event.target.value;
        this.service.get(url).subscribe(
          (res)=>{
           this.opts=res;
           console.log(res);
          }
        )
      }else{
        this.getData();
      }
      }
     

     getData() {
       this.service.get('http://localhost:8080/rest/employee/').subscribe(
         (res)=>{
          this.opts=res;
         }
       )
        }

  ngOnInit() {
  }

}
