package com.example.demo.controller;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.CrossOrigin;
import com.example.demo.dto.*;

@RestController
public class Controller {
	String sa[]= {"sample","countrys","sweet"};
	List <String> s= new ArrayList<>(Arrays.asList(sa));
	
	@CrossOrigin(origins="*")
	@GetMapping("/rest/employee/")
	public List<String> getEmployeeByID() {
		
		/*if(id.length()==0) {
			return s;
		}else {
			List <String> saa= new ArrayList<>();
			for(String key : s) {
				if(key.contains(id)) {
					saa.add(key);
				}
			}
			return saa;
		}*/
		return s;
	}
	@CrossOrigin(origins="*")
	@GetMapping("/rest/employeees/{id}")
	public List<String> getEmployeeByID(@PathVariable String id) {
		if(id.length()==0) {
			return s;
		}else {
			List <String> saa= new ArrayList<>();
			for(String key : s) {
				if(key.contains(id)) {
					saa.add(key);
				}
			}
			
			return saa;
		}
	}
	@PostMapping("/rest/employee/create/{id}")
	public Boolean  createEmployee(@PathVariable String id) {
		boolean value = s.add(id);
		return value;
	}
	
	
}
