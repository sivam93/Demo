package com.example.demo.dto;
import lombok.Setter;
import lombok.Getter;

@Getter @Setter
public class Sample {
	
	String id;
	
	String Sample;
}
